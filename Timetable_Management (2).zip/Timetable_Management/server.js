// Updated server.js to handle additional APIs for sessions, sections, and timetables
const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');
const bcrypt = require('bcrypt');

const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// MySQL connection
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root', // Replace with your MySQL username
    password: 'root', // Replace with your MySQL password
    database: 'Timetable_Management' // Correct database name
});

// Hash the password for debugging (for testing purposes only)
const hash = bcrypt.hashSync('123', 10);
console.log(`Hashed password for '123': ${hash}`);

db.connect(err => {
    if (err) throw err;
    console.log('Connected to MySQL database.');
});

// API to handle user login
app.post('/api/login', (req, res) => {
    console.log('Login route hit');
    const { username, password } = req.body;
    console.log('Received data:', { username, password });

    if (!username || !password) {
        return res.status(400).json({ success: false, message: 'Username and password are required' });
    }

    db.query('SELECT * FROM Users WHERE username = ?', [username], (err, results) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).send('Database error');
        }

        console.log('Database query results:', results);
        if (results.length > 0) {
            const user = results[0];
            if (bcrypt.compareSync(password, user.password_hash)) { // Use the correct column name
                console.log('Login successful for user:', username);
                res.json({ success: true, userId: user.user_id, role: user.role });
            } else {
                console.log('Invalid password for user:', username);
                res.status(401).json({ success: false, message: 'Invalid password' });
            }
        } else {
            console.log('User not found:', username);
            res.status(404).json({ success: false, message: 'User not found' });
        }
    });
});



// API to fetch all users
app.get('/api/users', (req, res) => {
    db.query('SELECT * FROM Users', (err, results) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).send(err);
        }
        console.log('Fetched users:', results); // Log query results
        res.json(results);
    });
});

// API to fetch a single user by ID
app.get('/api/users/:id', (req, res) => {
    const userId = req.params.id;
    db.query('SELECT * FROM Users WHERE user_id = ?', [userId], (err, results) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).send(err);
        }
        if (results.length > 0) {
            console.log('Fetched user:', results[0]); // Log user details
            res.json(results[0]);
        } else {
            console.log('User not found with ID:', userId);
            res.status(404).json({ success: false, message: 'User not found' });
        }
    });
});

// API to test database connection
app.get('/api/db', (req, res) => {
    db.query('SELECT DATABASE()', (err, results) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).send(err);
        }
        console.log('Connected database:', results); // Log connected database
        res.json(results);
    });
});


// API to add a department
app.post('/api/department', (req, res) => {
    const { department_name } = req.body;

    // Validate input
    if (!department_name) {
        return res.status(400).json({ success: false, message: 'Department name is required.' });
    }

    // Check for duplicate department names
    const duplicateCheckQuery = 'SELECT * FROM Departments WHERE department_name = ?';
    db.query(duplicateCheckQuery, [department_name], (err, results) => {
        if (err) {
            console.error('Database error during duplicate check:', err);
            return res.status(500).json({ success: false, message: 'Database error during duplicate check.' });
        }

        if (results.length > 0) {
            return res.status(400).json({ success: false, message: 'Department name already exists.' });
        }

        // Insert the department if no duplicates found
        const insertQuery = 'INSERT INTO Departments (department_name) VALUES (?)';
        db.query(insertQuery, [department_name], (err, result) => {
            if (err) {
                console.error('Database error during insertion:', err);
                return res.status(500).json({ success: false, message: 'Database error during insertion.' });
            }

            res.json({ success: true, message: 'Department added successfully.', department_id: result.insertId });
        });
    });
});

// API to add a program
app.post('/api/program', (req, res) => {
    const { program_name, department_id } = req.body;

    // Validate input
    if (!program_name || !department_id) {
        return res.status(400).json({ success: false, message: 'Program name and department ID are required.' });
    }

    // Validate that the department_id exists
    const validateDepartmentQuery = 'SELECT * FROM Departments WHERE department_id = ?';
    db.query(validateDepartmentQuery, [department_id], (err, results) => {
        if (err) {
            console.error('Database error during department validation:', err);
            return res.status(500).json({ success: false, message: 'Database error during department validation.' });
        }

        if (results.length === 0) {
            return res.status(400).json({ success: false, message: 'Invalid department ID.' });
        }

        // Insert the program after validating the department
        const insertQuery = 'INSERT INTO Programs (program_name, department_id) VALUES (?, ?)';
        db.query(insertQuery, [program_name, department_id], (err, result) => {
            if (err) {
                console.error('Database error during program insertion:', err);
                return res.status(500).json({ success: false, message: 'Database error during program insertion.' });
            }

            res.json({ success: true, message: 'Program added successfully.', program_id: result.insertId });
        });
    });
});


// API to add a course
app.post('/api/course', (req, res) => {
    const { course_name, program_id } = req.body; // Corrected typo from course_mame to course_name

    // Validate input
    if (!course_name || !program_id) {
        return res.status(400).json({ success: false, message: 'Course name and program ID are required.' });
    }

    // Validate that the program_id exists
    const validateProgramQuery = 'SELECT * FROM Programs WHERE program_id = ?';
    db.query(validateProgramQuery, [program_id], (err, results) => {
        if (err) {
            console.error('Database error during program validation:', err);
            return res.status(500).json({ success: false, message: 'Database error during program validation.' });
        }

        if (results.length === 0) {
            return res.status(400).json({ success: false, message: 'Invalid program ID.' });
        }

        // Insert the course after validating the program
        const insertQuery = 'INSERT INTO Courses (course_name, program_id) VALUES (?, ?)';
        db.query(insertQuery, [course_name, program_id], (err, result) => {
            if (err) {
                console.error('Database error during course insertion:', err);
                return res.status(500).json({ success: false, message: 'Database error during course insertion.' });
            }

            res.json({ success: true, message: 'Course added successfully.', course_id: result.insertId });
        });
    });
});


// API to add a teacher
app.post('/api/teacher', (req, res) => {
    const { teacher_name, department_id } = req.body;

    // Validate input
    if (!teacher_name || !department_id) {
        return res.status(400).json({ success: false, message: 'Teacher name and department ID are required.' });
    }

    // Validate that the department_id exists
    const validateDepartmentQuery = 'SELECT * FROM Departments WHERE department_id = ?';
    db.query(validateDepartmentQuery, [department_id], (err, results) => {
        if (err) {
            console.error('Database error during department validation:', err);
            return res.status(500).json({ success: false, message: 'Database error during department validation.' });
        }

        if (results.length === 0) {
            return res.status(400).json({ success: false, message: 'Invalid department ID.' });
        }

        // Insert the teacher after validating the department
        const insertQuery = 'INSERT INTO Teachers (teacher_name, department_id) VALUES (?, ?)';
        db.query(insertQuery, [teacher_name, department_id], (err, result) => {
            if (err) {
                console.error('Database error during teacher insertion:', err);
                return res.status(500).json({ success: false, message: 'Database error during teacher insertion.' });
            }

            res.json({ success: true, message: 'Teacher added successfully.', teacher_id: result.insertId });
        });
    });
});


// API to add a room
app.post('/api/room', (req, res) => {
    const { room_no, building, room_type } = req.body;

    // Validate input
    if (!room_no || !building || !room_type) {
        return res.status(400).json({ success: false, message: 'Room number, building, and room type are required.' });
    }

    // Check for duplicate room entries
    const duplicateCheckQuery = 'SELECT * FROM Rooms WHERE room_no = ? AND building = ?';
    db.query(duplicateCheckQuery, [room_no, building], (err, results) => {
        if (err) {
            console.error('Database error during duplicate check:', err);
            return res.status(500).json({ success: false, message: 'Database error during duplicate check.' });
        }

        if (results.length > 0) {
            return res.status(400).json({ success: false, message: 'Room already exists in the specified building.' });
        }

        // Insert the room if no duplicates found
        const insertQuery = 'INSERT INTO Rooms (room_no, building, room_type) VALUES (?, ?, ?)';
        db.query(insertQuery, [room_no, building, room_type], (err, result) => {
            if (err) {
                console.error('Database error during room insertion:', err);
                return res.status(500).json({ success: false, message: 'Database error during room insertion.' });
            }

            res.json({ success: true, message: 'Room added successfully.', room_id: result.insertId });
        });
    });
});


// API to add a session
app.post('/api/session', (req, res) => {
    const { session_name, session_year, session_type } = req.body;

    // Validate input
    if (!session_name || !session_year || !session_type) {
        return res.status(400).json({ success: false, message: 'Session name, year, and type are required.' });
    }

    // Check for duplicate session entries
    const duplicateCheckQuery = 'SELECT * FROM Sessions WHERE session_name = ? AND session_year = ?';
    db.query(duplicateCheckQuery, [session_name, session_year], (err, results) => {
        if (err) {
            console.error('Database error during duplicate check:', err);
            return res.status(500).json({ success: false, message: 'Database error during duplicate check.' });
        }

        if (results.length > 0) {
            return res.status(400).json({ success: false, message: 'Session with the same name and year already exists.' });
        }

        // Insert the session if no duplicates found
        const insertQuery = 'INSERT INTO Sessions (session_name, session_year, session_type) VALUES (?, ?, ?)';
        db.query(insertQuery, [session_name, session_year, session_type], (err, result) => {
            if (err) {
                console.error('Database error during session insertion:', err);
                return res.status(500).json({ success: false, message: 'Database error during session insertion.' });
            }

            res.json({ success: true, message: 'Session added successfully.', session_id: result.insertId });
        });
    });
});

// API to add a section
app.post('/api/section', (req, res) => {
    const { section_name, Semester, Program_id } = req.body;

    // Validate input
    if (!section_name || !Semester || !Program_id) {
        return res.status(400).json({ success: false, message: 'Section name, semester, and program ID are required.' });
    }

    // Validate that the Program_id exists
    const validateProgramQuery = 'SELECT * FROM Programs WHERE program_id = ?';
    db.query(validateProgramQuery, [Program_id], (err, results) => {
        if (err) {
            console.error('Database error during program validation:', err);
            return res.status(500).json({ success: false, message: 'Database error during program validation.' });
        }

        if (results.length === 0) {
            return res.status(400).json({ success: false, message: 'Invalid program ID.' });
        }

        // Check for duplicate section entries
        const duplicateCheckQuery = 'SELECT * FROM Sections WHERE section_name = ? AND semester = ? AND program_id = ?';
        db.query(duplicateCheckQuery, [section_name, Semester, Program_id], (err, results) => {
            if (err) {
                console.error('Database error during duplicate check:', err);
                return res.status(500).json({ success: false, message: 'Database error during duplicate check.' });
            }

            if (results.length > 0) {
                return res.status(400).json({ success: false, message: 'Section with the same name, semester, and program already exists.' });
            }

            // Insert the section if no duplicates found
            const insertQuery = 'INSERT INTO Sections (section_name, semester, program_id) VALUES (?, ?, ?)';
            db.query(insertQuery, [section_name, Semester, Program_id], (err, result) => {
                if (err) {
                    console.error('Database error during section insertion:', err);
                    return res.status(500).json({ success: false, message: 'Database error during section insertion.' });
                }

                res.json({ success: true, message: 'Section added successfully.', section_id: result.insertId });
            });
        });
    });
});


// API to add a timetable entry
app.post('/api/timetable', (req, res) => {
    const { day, start_time, end_time, course_id, teacher_id, room_id, section_id } = req.body;

    // Validate input
    if (!day || !start_time || !end_time || !course_id || !teacher_id || !room_id || !section_id) {
        return res.status(400).json({ success: false, message: 'All timetable fields are required.' });
    }

    // Validate foreign keys for course_id, teacher_id, room_id, and section_id
    const validateForeignKeysQuery = `
        SELECT
            (SELECT COUNT(*) FROM Courses WHERE course_id = ?) AS course_exists,
            (SELECT COUNT(*) FROM Teachers WHERE teacher_id = ?) AS teacher_exists,
            (SELECT COUNT(*) FROM Rooms WHERE room_id = ?) AS room_exists,
            (SELECT COUNT(*) FROM Sections WHERE section_id = ?) AS section_exists
    `;
    db.query(validateForeignKeysQuery, [course_id, teacher_id, room_id, section_id], (err, results) => {
        if (err) {
            console.error('Database error during foreign key validation:', err);
            return res.status(500).json({ success: false, message: 'Database error during foreign key validation.' });
        }

        const { course_exists, teacher_exists, room_exists, section_exists } = results[0];
        if (!course_exists || !teacher_exists || !room_exists || !section_exists) {
            return res.status(400).json({ success: false, message: 'Invalid foreign key(s) provided.' });
        }

        // Check for time slot conflicts for the same room or teacher
        const conflictCheckQuery = `
            SELECT * FROM Timetable
            WHERE day = ? AND (
                (start_time < ? AND end_time > ?) OR
                (start_time < ? AND end_time > ?)
            ) AND (room_id = ? OR teacher_id = ?)
        `;
        db.query(conflictCheckQuery, [day, end_time, start_time, start_time, end_time, room_id, teacher_id], (err, conflicts) => {
            if (err) {
                console.error('Database error during conflict check:', err);
                return res.status(500).json({ success: false, message: 'Database error during conflict check.' });
            }

            if (conflicts.length > 0) {
                return res.status(400).json({ success: false, message: 'Time slot conflict detected for the same room or teacher.' });
            }

            // Insert the timetable entry if no conflicts or validation issues
            const insertQuery = `
                INSERT INTO Timetable (day, start_time, end_time, course_id, teacher_id, room_id, section_id)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            `;
            db.query(insertQuery, [day, start_time, end_time, course_id, teacher_id, room_id, section_id], (err, result) => {
                if (err) {
                    console.error('Database error during timetable insertion:', err);
                    return res.status(500).json({ success: false, message: 'Database error during timetable insertion.' });
                }

                res.json({ success: true, message: 'Timetable entry added successfully.', timetable_id: result.insertId });
            });
        });
    });
});

// Serve static files
app.use(express.static(path.join(__dirname, 'public')));

// Serve login page at the root
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public/login.html'));
});

// Serve dashboard
app.get('/dashboard', (req, res) => {
    res.sendFile(path.join(__dirname, 'public/dash.html'));
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});
