

// script.js

// Main function to handle form opening based on the selected option
// Global arrays to store data
let departments = [];
let programs = [];
let courses = [];
let teachers = [];
let rooms = [];
let sessions = [];
let sections = [];

// Unified openForm function
function openForm(formId) {
    switch (formId) {
        case 'dashboard':
            showDashboard();
            break;
        case 'timetableForm':
                openTimetableModal();
            break;
        case 'addDepartment':
            openFormModal('Add Department', ['departmentId', 'departmentName'], saveDepartment);
            break;
        case 'listDepartment':
            showList('department', departments);
            break;
         case 'addProgram':
                openFormModal('Add Program',
                    ['programId', 'programName'], // Changed to use departmentId
                    saveProgram,
                    { programId: '', programName: '' }, // Removed departmentName from currentValues
                    populateDepartmentDropdown() // Pass the dropdown HTML
                );
            break;
            
        case 'listProgram':
            showList('program', programs);
            break;
        case 'addCourse':
                openFormModal('Add Course', 
                    ['courseId', 'courseName', ], // Remove programId from here
                    saveCourse,
                    { courseId: '', courseName: ''}, // Keep the same current values
                    populateProgramDropdown() // Pass the dropdown HTML for programs
                );
            break;
        case 'listCourse':
            showList('course', courses);
            break;
        case 'addTeacher':
                openFormModal('Add Teacher', 
                    ['teacherId', 'teacherName'], 
                    saveTeacher,
                    { teacherId: '', teacherName: '' }, 
                    populateDepartmentDropdown() // Add the department dropdown
                );
            break;
                        
        case 'listTeacher':
            showList('teacher', teachers);
            break;
        case 'addRoom':
            openFormModal('Add Room', 
                ['roomNo', 'building', 'roomType'], 
                saveRoom,
                { roomNo: '', building: '', roomType: '' }
            );
            break;
        case 'listRoom':
            showList('room', rooms);
            break;
        case 'addSession':
            openFormModal('Add Session', 
                ['sessionId', 'sessionName', 'sessionYear', 'sessionType'], 
                saveSession,
                { sessionId: '', sessionName: '', sessionYear: '', sessionType: '' }
            );
            break;
        case 'listSession':
            showList('session', sessions);
            break;
        case 'addSection':
                openFormModal(
                    'Add Section',
                    ['sectionId', 'sectionName', 'semester'],
                    saveSection,
                    { sectionId: '', sectionName: '', semester: '' },
                    populateProgramDropdown() // Include program dropdown
                );
            break;            
        case 'listSection':
            showList('section', sections);
            break;
    }
}

function showDashboard() {
    const timetableGrid = document.getElementById('timetableGrid');
    const formContainer = document.getElementById('formContainer');

    // Hide the timetable grid
    timetableGrid.style.display = 'none';

    // Show dashboard content
    formContainer.innerHTML = `
        <h2 class="welcome-message">Welcome to the Dashboard</h2>
        <div class="dashboard-cards">
            <div class="card" style="background: linear-gradient(135deg, #3498db, #8e44ad);" onclick="showList('course', courses)">
                <i class="fas fa-book card-icon"></i>
                <h3>Courses</h3>
                <p>Manage your courses</p>
            </div>
            <div class="card" style="background: linear-gradient(135deg, #3498db, #8e44ad);" onclick="showList('department', departments)">
                <i class="fas fa-building card-icon"></i>
                <h3>Departments</h3>
                <p>Organize departments</p>
            </div>
            <div class="card" style="background: linear-gradient(135deg, #3498db, #8e44ad);" onclick="showList('room', rooms)">
                <i class="fas fa-door-closed card-icon"></i>
                <h3>Rooms</h3>
                <p>Allocate and manage rooms</p>
            </div>
            <div class="card" style="background: linear-gradient(135deg, #3498db, #8e44ad);" onclick="showList('program', programs)">
                <i class="fas fa-graduation-cap card-icon"></i>
                <h3>Programs</h3>
                <p>Organize academic programs</p>
            </div>
            <div class="card" style="background: linear-gradient(135deg, #3498db, #8e44ad);" onclick="showList('teacher', teachers)">
                <i class="fas fa-chalkboard-teacher card-icon"></i>
                <h3>Teachers</h3>
                <p>Manage teacher assignments</p>
            </div>
            <div class="card" style="background: linear-gradient(135deg, #3498db, #8e44ad);" onclick="showList('session', sessions)">
                <i class="fas fa-clock card-icon"></i>
                <h3>Sessions</h3>
                <p>Plan academic sessions</p>
            </div>
            <div class="card" style="background: linear-gradient(135deg, #3498db, #8e44ad);" onclick="showTimetable()">
                <i class="fas fa-calendar-alt card-icon"></i>
                <h3>Class Time Table</h3>
                <p>View and manage timetables</p>
            </div>
        </div>
    `;

    
}
// Add event listener to the login button
document.getElementById('btn').addEventListener('click', () => {
    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value.trim();

    if (!username || !password) {
        alert('Please enter both username and password.');
        return;
    }

    // Send login details to the backend
    fetch('http://localhost:3000/api/login', { // Backend URL
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ username, password })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            window.location.href = 'dash.html'; // Redirect on successful login
        } else {
            alert(data.message || 'Login failed.');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('An error occurred. Please try again.');
    });
});


// Save a department
document.getElementById('saveDepartmentBtn')?.addEventListener('click', () => {
    const departmentName = document.getElementById('departmentName').value.trim();

    if (!departmentName) {
        alert('Please enter a department name.');
        return;
    }

    fetch('http://localhost:3000/api/department', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ department_name: departmentName }),
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Department added successfully!');
            } else {
                alert(data.message || 'Failed to add department.');
            }
        })
        .catch(error => console.error('Error:', error));
});

// Save a program
document.getElementById('saveProgramBtn')?.addEventListener('click', () => {
    const programName = document.getElementById('programName').value.trim();
    const departmentId = document.getElementById('programDepartmentId').value;

    if (!programName || !departmentId) {
        alert('Please enter a program name and select a department.');
        return;
    }

    // Updated field name to match the database column
    fetch('http://localhost:3000/api/program', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ program_name: programName, department_id: departmentId }), // Changed programName to program_name, departmentId to department_id
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Program added successfully!');
            } else {
                alert(data.message || 'Failed to add program.');
            }
        })
        .catch(error => console.error('Error:', error));
});


// Save a course
document.getElementById('saveCourseBtn')?.addEventListener('click', () => {
    const courseName = document.getElementById('courseName').value.trim();
    const programId = document.getElementById('courseProgramId').value;

    if (!courseName || !programId) {
        alert('Please enter a course name and select a program.');
        return;
    }

    fetch('http://localhost:3000/api/course', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ course_name: courseName, program_id: programId  }),
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Course added successfully!');
            } else {
                alert(data.message || 'Failed to add course.');
            }
        })
        .catch(error => console.error('Error:', error));
});

// Save a teacher
document.getElementById('saveTeacherBtn')?.addEventListener('click', () => {
    const teacherName = document.getElementById('teacherName').value.trim();
    const departmentId = document.getElementById('teacherDepartmentId').value;

    if (!teacherName || !departmentId) {
        alert('Please enter a teacher name and select a department.');
        return;
    }

    fetch('http://localhost:3000/api/teacher', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ teacher_name: teacherName, department_id: departmentId }),
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Teacher added successfully!');
            } else {
                alert(data.message || 'Failed to add teacher.');
            }
        })
        .catch(error => console.error('Error:', error));
});

// Save a room
document.getElementById('saveRoomBtn')?.addEventListener('click', () => {
    const roomNo = document.getElementById('roomNo').value.trim();
    const building = document.getElementById('roomBuilding').value.trim();
    const roomType = document.getElementById('roomType').value;

    if (!roomNo || !building || !roomType) {
        alert('Please enter room details.');
        return;
    }

    fetch('http://localhost:3000/api/room', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ room_name: roomName, building, room_type: roomType  }),
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Room added successfully!');
            } else {
                alert(data.message || 'Failed to add room.');
            }
        })
        .catch(error => console.error('Error:', error));
});

// Save a session
document.getElementById('saveSessionBtn')?.addEventListener('click', () => {
    const sessionName = document.getElementById('sessionName').value.trim();
    const sessionYear = document.getElementById('sessionYear').value.trim();
    const sessionType = document.getElementById('sessionType').value;

    if (!sessionName || !sessionYear || !sessionType) {
        alert('Please fill in all session fields.');
        return;
    }

    fetch('http://localhost:3000/api/session', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ session_name: sessionName, session_year: sessionYear, session_type: sessionType  }),
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Session added successfully!');
            } else {
                alert(data.message || 'Failed to add session.');
            }
        })
        .catch(error => console.error('Error:', error));
});

// Save a section
document.getElementById('saveSectionBtn')?.addEventListener('click', () => {
    const sectionName = document.getElementById('sectionName').value.trim();
    const sectionSemester = document.getElementById('sectionSemester').value.trim();
    const sectionProgramId = document.getElementById('sectionProgramId').value.trim();

    if (!sectionName || !sectionSemester || !sectionProgramId) {
        alert('Please fill in all section fields.');
        return;
    }

    fetch('http://localhost:3000/api/section', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ section_name: sectionName, semester: sectionSemester, program_id: sectionProgramId }),
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Section added successfully!');
            } else {
                alert(data.message || 'Failed to add section.');
            }
        })
        .catch(error => console.error('Error:', error));
});


/* Save a timetable entry*/
document.getElementById('saveTimetableBtn')?.addEventListener('click', () => {
    const timetableDay = document.getElementById('timetableDay').value;
    const timetableStartTime = document.getElementById('timetableStartTime').value;
    const timetableEndTime = document.getElementById('timetableEndTime').value;
    const timetableCourseId = document.getElementById('timetableCourseId').value.trim();
    const timetableTeacherId = document.getElementById('timetableTeacherId').value.trim();
    const timetableRoomId = document.getElementById('timetableRoomId').value.trim();
    const timetableSectionId = document.getElementById('timetableSectionId').value.trim();

    if (!timetableDay || !timetableStartTime || !timetableEndTime || !timetableCourseId || !timetableTeacherId || !timetableRoomId || !timetableSectionId) {
        alert('Please fill in all timetable fields.');
        return;
    }

    fetch('http://localhost:3000/api/timetable', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            timetableDay,
            timetableStartTime,
            timetableEndTime,
            timetableCourseId,
            timetableTeacherId,
            timetableRoomId,
            timetableSectionId,
        }),
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Timetable entry added successfully!');
            } else {
                alert(data.message || 'Failed to add timetable entry.');
            }
        })
        .catch(error => console.error('Error:', error));
});



// Show list for a specific section
function showList(section, data) {
    const formContainer = document.getElementById('formContainer');
    let sectionTitle = '';
    let sectionContent = '';

    switch (section) {
        case 'department':
            sectionTitle = 'Departments';
            sectionContent = renderTable(data, ['ID', 'Name'], ['id', 'name']);
            break;
        case 'program':
            sectionTitle = 'Programs';
            sectionContent = renderTable(data, ['ID', 'Name'], ['id', 'name']);
            break;
        case 'session':
            sectionTitle = 'Sessions';
            sectionContent = renderTable(data, ['ID', 'Name', 'Year', 'Type'], ['id', 'name', 'year', 'type']);
            break;
        case 'section':
            sectionTitle = 'Sections';
            sectionContent = renderTable(data, ['ID', 'Name', 'Semester'], ['id', 'name', 'semester']);
            break;
        case 'room':
            sectionTitle = 'Rooms';
            sectionContent = renderTable(data, ['Room No', 'Building', 'Type'], ['roomNo', 'building', 'type']);
            break;
        case 'course':
            sectionTitle = 'Courses';
            sectionContent = renderTable(data, ['ID', 'Name'], ['id', 'name']);
            break;
        case 'teacher':
            sectionTitle = 'Teachers';
            sectionContent = renderTable(data, ['ID', 'Name'], ['id', 'name']);
            break;
        default:
            alert('Unknown section');
            return;
    }

    formContainer.innerHTML = `
        <h3>${sectionTitle}</h3>
        ${sectionContent}
    `;
}

// Function to render a table for any list
function renderTable(data, headers, fields) {
    if (!data || data.length === 0) {
        return '<p>No data available.</p>';
    }

    const headerRow = headers.map(header => `<th>${header}</th>`).join('');
    const rows = data
        .map(
            item =>
                `<tr>${fields
                    .map(field => `<td>${item[field] || ''}</td>`)
                    .join('')}</tr>`
        )
        .join('');

    return `
        <table class="data-table">
            <thead>
                <tr>${headerRow}</tr>
            </thead>
            <tbody>
                ${rows}
            </tbody>
        </table>
    `;
}

// Show Timetable
function showTimetable() {
    const formContainer = document.getElementById('formContainer');
    formContainer.innerHTML = `
        <h3>Class Timetable</h3>
        <button onclick="viewSavedTimetables()">View Saved Timetables</button>
        <button onclick="openAddTimetableModal()">Add New Timetable</button>
    `;
}

document.addEventListener("DOMContentLoaded", () => {
    showDashboard();
});


// Modal form handler
function openFormModal(formTitle, inputFields, saveFunction, currentValues = {}, dropdownHTML = '') {
    const formContainer = document.getElementById('formContainer');
    let inputsHtml = inputFields.map(field => 
        `<input type="text" id="${field}" value="${currentValues[field] || ''}" placeholder="Enter ${field.replace(/([A-Z])/g, ' $1').trim()}" required>`
    ).join('');

    // Include the dropdown HTML in the modal
    if (dropdownHTML) {
        inputsHtml += dropdownHTML;
    }

    formContainer.innerHTML = `
        <div class="overlay" onclick="closeFormModal()"></div>
        <div class="form-modal">
            <button class="close-btn" onclick="closeFormModal()">X</button>
            <h3>${formTitle}</h3>
            ${inputsHtml}
            <button id="saveButton">Save</button>
        </div>
    `;
    document.querySelector('.overlay').style.display = 'block';
    document.querySelector('.form-modal').style.display = 'block';

    // Add event listener to the save button
    document.getElementById('saveButton').addEventListener('click', function() {
        if (validateAllInputs(inputFields)) {
            saveFunction();
        }
    });
}

// Function to update the roomType input when a selection is made
function updateRoomTypeInput(value) {
    const roomTypeInput = document.getElementById('roomType');
    if (roomTypeInput) {
        roomTypeInput.value = value;
    }
}

// Close the form modal
function closeFormModal() {
    document.querySelector('.overlay').style.display = 'none';
    document.querySelector('.form-modal').style.display = 'none';
}

// Input validation function
function validateInput(inputId, errorMessage) {
    const input = document.getElementById(inputId);
    if (!input.value.trim()) {
        alert(errorMessage);
        return false;
    }
    return true;
}

// Validate all required inputs in the form
function validateAllInputs(inputFields) {
    return inputFields.every(field => 
        validateInput(field, `${field.replace(/([A-Z])/g, ' $1').trim()} is required`)
    );
}


function saveDepartment() {
    if (!validateInput('departmentId', 'Department ID is required') ||
        !validateInput('departmentName', 'Department Name is required')) {
        return;
    }
    const departmentId = document.getElementById('departmentId').value;
    const departmentName = document.getElementById('departmentName').value;
    departments.push({ id: departmentId, name: departmentName });
    closeFormModal();
    showList('department', departments);
    showSuccessMessage('Department added successfully!');
}

// Function to display department list

function showDepartmentList() {
    const formContainer = document.getElementById('formContainer');
    formContainer.innerHTML = `
        <h3 class="padded-heading"> Departments List</h3>
        <table class="department-table">
            <thead>
                <tr>
                    <th>Department ID</th>
                    <th>Department Name</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                ${departments.map((dept, index) => `
                    <tr>
                        <td id="dept-id-${index}" contenteditable="false">${dept.id}</td>
                        <td id="dept-name-${index}" contenteditable="false">${dept.name}</td>
                        <td>
                            <button class="edit-btn" id="edit-btn-${index}" onclick="toggleEditing(${index})">Edit</button>
                            <button class="remove-btn" onclick="removeDepartment(${index})">Remove</button>
                        </td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
    updateDepartmentDropdowns(); // Ensure dropdowns are updated whenever the list is rendered
}

// Function to toggle editing for a department
function toggleDepartmentEditing(index) {
    const idCell = document.getElementById(`department-id-${index}`);
    const nameCell = document.getElementById(`department-name-${index}`);
    const editButton = document.getElementById(`department-edit-btn-${index}`);

    if (idCell.contentEditable === "false") {
        // Enable editing
        [idCell, nameCell].forEach(cell => {
            cell.contentEditable = "true";
            cell.style.border = "1px solid #3498db";
            cell.dataset.originalValue = cell.textContent.trim(); // Store original value
        });

        editButton.textContent = "Save";
    } else {
        // Validate and save changes
        const newId = idCell.textContent.trim();
        const newName = nameCell.textContent.trim();

        if (!newId || !newName) {
            alert("Both fields are required.");
            [idCell, nameCell].forEach(cell => {
                cell.textContent = cell.dataset.originalValue; // Revert to original value
            });
            return;
        }

        // Check for duplicate department IDs
        if (departments.some((dept, deptIndex) => dept.id === newId && deptIndex !== index)) {
            alert("Department ID already exists. Please use a unique ID.");
            idCell.textContent = idCell.dataset.originalValue; // Revert to original value
            return;
        }

        // Update department
        departments[index] = {
            id: newId,
            name: newName
        };

        showDepartmentList();
        showSuccessMessage("Department updated successfully!");
    }
}

// Function to remove a department
function removeDepartment(index) {
    const departmentName = departments[index].name;
    departments.splice(index, 1); // Remove from the list
    showDepartmentList(); // Refresh the department list
    showSuccessMessage(`${departmentName} has been removed successfully!`);
}


showDepartmentList();


function populateDropdown(entityType, dropdownId, selectedId = '') {
    const apiEndpoint = `http://localhost:3000/api/${entityType}`;

    fetch(apiEndpoint)
        .then(response => {
            if (!response.ok) throw new Error(`Failed to fetch ${entityType}`);
            return response.json();
        })
        .then(data => {
            const dropdown = document.getElementById(dropdownId);
            dropdown.innerHTML = `<option value="">Select ${entityType.charAt(0).toUpperCase() + entityType.slice(1)}</option>`;
            data.forEach(item => {
                const option = document.createElement('option');
                option.value = item[`${entityType}_id`] || item.id;
                option.textContent = item[`${entityType}_name`] || item.name || item.fullName;
                if (item[`${entityType}_id`] === selectedId || item.id === selectedId) {
                    option.selected = true; // Pre-select the current item
                }
                dropdown.appendChild(option);
            });
        })
        .catch(err => console.error(`Error populating ${entityType}:`, err));
}



// Function to save a session
function saveSession() {
    if (!validateInput('sessionId', 'Session ID is required') ||
        !validateInput('sessionName', 'Session Name is required') ||
        !validateInput('sessionYear', 'Session Year is required') ||
        !validateInput('sessionType', 'Session Type is required')) {
        return;
    }

    const sessionId = document.getElementById('sessionId').value.trim();
    const sessionName = document.getElementById('sessionName').value.trim();
    const sessionYear = document.getElementById('sessionYear').value.trim();
    const sessionType = document.getElementById('sessionType').value.trim();

    // Prevent duplicate Session IDs
    if (sessions.some(session => session.id === sessionId)) {
        showErrorMessage('Session ID already exists!');
        return;
    }

    // Add session to the list
    sessions.push({
        id: sessionId,
        name: sessionName,
        year: sessionYear,
        type: sessionType,
        fullName: `${sessionType} ${sessionYear}`
    });

    closeFormModal();
    showSessionList();
    showSuccessMessage('Session added successfully!');
}

// Function to display session list
function showSessionList() {
    const formContainer = document.getElementById('formContainer');
    formContainer.innerHTML = `
        <h3>Session List</h3>
        <table class="session-table">
            <thead>
                <tr>
                    <th>Session ID</th>
                    <th>Session Name</th>
                    <th>Year</th>
                    <th>Type</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                ${sessions.map((session, index) => `
                    <tr>
                        <td id="session-id-${index}" contenteditable="false">${session.id}</td>
                        <td id="session-name-${index}" contenteditable="false">${session.name}</td>
                        <td id="session-year-${index}" contenteditable="false">${session.year}</td>
                        <td id="session-type-${index}" contenteditable="false">${session.type}</td>
                        <td>
                            <button class="edit-btn" id="session-edit-btn-${index}" onclick="toggleSessionEditing(${index})">Edit</button>
                            <button class="remove-btn" onclick="removeSession(${index})">Remove</button>
                        </td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
}

// Function to toggle editing for a session
function toggleSessionEditing(index) {
    const idCell = document.getElementById(`session-id-${index}`);
    const nameCell = document.getElementById(`session-name-${index}`);
    const yearCell = document.getElementById(`session-year-${index}`);
    const typeCell = document.getElementById(`session-type-${index}`);
    const editButton = document.getElementById(`session-edit-btn-${index}`);

    if (editButton.textContent === "Edit") {
        [idCell, nameCell, yearCell, typeCell].forEach(cell => {
            cell.contentEditable = "true";
            cell.style.border = "1px solid #3498db";
            cell.dataset.originalValue = cell.textContent.trim();
        });

        editButton.textContent = "Save";
    } else {
        const newId = idCell.textContent.trim();
        const newName = nameCell.textContent.trim();
        const newYear = yearCell.textContent.trim();
        const newType = typeCell.textContent.trim();

        if (!newId || !newName || !newYear || !newType) {
            alert('All fields are required!');
            [idCell, nameCell, yearCell, typeCell].forEach(cell => {
                cell.textContent = cell.dataset.originalValue; // Revert changes
            });
        } else {
            // Update session details
            sessions[index] = {
                id: newId,
                name: newName,
                year: newYear,
                type: newType,
                fullName: `${newType} ${newYear}`
            };

            showSuccessMessage('Session updated successfully!');
        }

        [idCell, nameCell, yearCell, typeCell].forEach(cell => {
            cell.contentEditable = "false";
            cell.style.border = "none";
        });

        editButton.textContent = "Edit";
        showSessionList(); // Refresh the list after saving
    }
}

// Function to remove a session
function removeSession(index) {
    {
        sessions.splice(index, 1); // Remove session from the array
        showSessionList(); // Refresh the session list
        showSuccessMessage('Session removed successfully!');
    }
}

// Initial render of the session list
showSessionList();


function saveProgram() {
    const requiredFields = ['programId', 'programName', 'departmentId'];
    if (!validateAllInputs(requiredFields)) {
        return;
    }

    const programId = document.getElementById('programId').value.trim();
    const programName = document.getElementById('programName').value.trim();
    const departmentId = document.getElementById('departmentId').value.trim();

    // Fetch the selected department
    const department = departments.find(dept => dept.id === departmentId);
    if (!department) {
        showErrorMessage("Invalid Department selected.");
        return;
    }

    // Push the new program with department info
    programs.push({
        id: programId,
        name: programName,
        departmentId: departmentId,
        departmentName: department.name
    });

    closeFormModal();
    showProgramList();
    showSuccessMessage('Program added successfully!');
}


function showProgramList() {
    const formContainer = document.getElementById('formContainer');
    const tableHTML = `
        <h3>Programs List</h3>
        <table class="program-table">
            <thead>
                <tr>
                    <th>Program ID</th>
                    <th>Program Name</th>
                    <th>Department Name</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                ${programs.map((program, index) => `
                    <tr>
                        <td id="program-id-${index}" contenteditable="false">${program.id}</td>
                        <td id="program-name-${index}" contenteditable="false">${program.name}</td>
                        <td id="program-department-${index}" contenteditable="false">${program.departmentName}</td>
                        <td>
                            <button class="edit-btn" id="program-edit-btn-${index}" onclick="toggleProgramEditing(${index})">Edit</button>
                            <button class="remove-btn" onclick="removeProgram(${index})">Remove</button>
                        </td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
    formContainer.innerHTML = tableHTML;
}

function toggleProgramEditing(index) {
    const idCell = document.getElementById(`program-id-${index}`);
    const nameCell = document.getElementById(`program-name-${index}`);
    const departmentCell = document.getElementById(`program-department-${index}`);
    const editButton = document.getElementById(`program-edit-btn-${index}`);

    if (idCell.contentEditable === "false") {
        [idCell, nameCell].forEach(cell => {
            cell.contentEditable = "true";
            cell.style.border = "1px solid #3498db";
            cell.dataset.originalValue = cell.textContent.trim();
        });

        departmentCell.innerHTML = populateDepartmentDropdown(programs[index].departmentId);
        editButton.textContent = "Save";
    } else {
        const departmentDropdown = document.getElementById('departmentId');
        const selectedDepartmentId = departmentDropdown.value;
        const department = departments.find(dept => dept.id === selectedDepartmentId);

        programs[index] = {
            id: idCell.textContent.trim(),
            name: nameCell.textContent.trim(),
            departmentId: selectedDepartmentId,
            departmentName: department ? department.name : ''
        };

        showProgramList();
        showSuccessMessage("Program updated successfully!");
    }
}

function removeProgram(index) {
    const programName = programs[index].name;
    programs.splice(index, 1);
    showProgramList();
    showSuccessMessage(`${programName} has been removed successfully!`);
}

function populateDepartmentDropdown(selectedDepartmentId) {
    const dropdown = document.createElement('select');
    dropdown.id = 'departmentId';
    dropdown.name = 'departmentId';
    dropdown.required = true;

    const defaultOption = document.createElement('option');
    defaultOption.value = '';
    defaultOption.textContent = 'Select Department';
    dropdown.appendChild(defaultOption);

    departments.forEach(department => {
        const option = document.createElement('option');
        option.value = department.id;
        option.textContent = department.name;
        if (department.id === selectedDepartmentId) {
            option.selected = true;
        }
        dropdown.appendChild(option);
    });

    return dropdown.outerHTML;
}



// Function to save a section
function saveSection() {
    if (!validateInput('sectionId', 'Section ID is required') ||
        !validateInput('sectionName', 'Section Name is required') ||
        !validateInput('semester', 'Semester is required') ||
        !validateInput('programId', 'Program selection is required')) { // Validate program selection
        return;
    }

    const sectionId = document.getElementById('sectionId').value;
    const sectionName = document.getElementById('sectionName').value;
    const semester = document.getElementById('semester').value;
    const programId = document.getElementById('programId').value; // Get selected program ID

    // Find the program name using the programId
    const program = programs.find(prog => prog.id === programId); // Find the program
    const programName = program ? program.name : ''; // Get the program name based on ID

    // Add new section to the sections array
    sections.push({
        id: sectionId,
        name: sectionName,
        semester: semester,
        programName // Save program name instead of program ID
    });

    closeFormModal(); // Close the modal
    showSectionList(); // Display the updated section list
    showSuccessMessage('Section added successfully!');
}

// Function to display the section list
function showSectionList() {
    const formContainer = document.getElementById('formContainer');
    formContainer.innerHTML = `
        <h3>Sections List</h3>
        <table class="section-table">
            <thead>
                <tr>
                    <th>Section ID</th>
                    <th>Section Name</th>
                    <th>Semester</th>
                    <th>Program Name</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                ${sections.map((section, index) => `
                    <tr>
                        <td id="section-id-${index}" contenteditable="false">${section.id}</td>
                        <td id="section-name-${index}" contenteditable="false">${section.name}</td>
                        <td id="section-semester-${index}" contenteditable="false">${section.semester}</td>
                        <td id="section-program-${index}" contenteditable="false">${section.programName}</td>
                        <td>
                            <button class="edit-btn" id="section-edit-btn-${index}" onclick="toggleSectionEditing(${index})">Edit</button>
                            <button class="remove-btn" onclick="removeSection(${index})">Remove</button>
                        </td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
}

function toggleSectionEditing(index) {
    const idCell = document.getElementById(`section-id-${index}`);
    const nameCell = document.getElementById(`section-name-${index}`);
    const semesterCell = document.getElementById(`section-semester-${index}`);
    const programCell = document.getElementById(`section-program-${index}`);
    const editButton = document.getElementById(`section-edit-btn-${index}`);

    if (idCell.contentEditable === "false") {
        [idCell, nameCell, semesterCell].forEach(cell => {
            cell.contentEditable = "true";
            cell.style.border = "1px solid #3498db";
            cell.dataset.originalValue = cell.textContent.trim();
        });

        // Replace program name with dropdown
        programCell.innerHTML = populateProgramDropdown(sections[index].programId);

        editButton.textContent = "Save";
    } else {
        const programDropdown = document.getElementById('programId');
        const selectedProgramId = programDropdown.value;
        const program = programs.find(prog => prog.id === selectedProgramId);

        sections[index] = {
            id: idCell.textContent.trim(),
            name: nameCell.textContent.trim(),
            semester: semesterCell.textContent.trim(),
            programId: selectedProgramId,
            programName: program ? program.name : ''
        };

        showSectionList();
        showSuccessMessage("Section updated successfully!");
    }
}

// Function to save section changes on Enter key press
function saveSectionOnEnter(event, index, field, cell) {
    if (event.key === "Enter") {
        event.preventDefault(); // Prevent default Enter behavior

        const newValue = cell.textContent.trim();

        // Validate input
        if (!newValue) {
            alert(`${field.charAt(0).toUpperCase() + field.slice(1)} cannot be empty.`);
            cell.textContent = cell.dataset.originalValue; // Revert to original value
        } else {
            // Update the sections array
            sections[index][field] = newValue;
        }

        // Disable editing and remove the border
        cell.contentEditable = "false";
        cell.style.border = "none";

        // Update the button text back to "Edit"
        const editButton = document.getElementById(`section-edit-btn-${index}`);
        editButton.textContent = "Edit";

        // Show success message
        showSuccessMessage("Section updated successfully!");
    }
}

// Function to save section changes explicitly
function saveSectionChanges(index, idCell, nameCell, semesterCell, programCell) {
    const newId = idCell.textContent.trim();
    const newName = nameCell.textContent.trim();
    const newSemester = semesterCell.textContent.trim();
    const newProgramName = programCell.textContent.trim();

    // Prevent empty inputs; revert to original values
    if (!newId) idCell.textContent = idCell.dataset.originalValue;
    if (!newName) nameCell.textContent = nameCell.dataset.originalValue;
    if (!newSemester) semesterCell.textContent = semesterCell.dataset.originalValue;
    if (!newProgramName) programCell.textContent = programCell.dataset.originalValue;

    // Update the sections array
    sections[index] = {
        id: idCell.textContent.trim(),
        name: nameCell.textContent.trim(),
        semester: semesterCell.textContent.trim(),
        programName: programCell.textContent.trim()
    };

    // Show success message
    showSuccessMessage("Section updated successfully!");
}

// Function to remove a section
function removeSection(index) {
    const sectionName = sections[index].name; // Get the name of the section being removed
    sections.splice(index, 1); // Remove the section from the array
    showSectionList(); // Refresh the section list
    showSuccessMessage(`${sectionName} has been removed successfully!`); // Show success message
}

// Display the section list on load
showSectionList();


function populateProgramDropdown(selectedProgramId = '') {
    const dropdown = document.createElement('select');
    dropdown.id = 'programId'; // ID for referencing the selected program
    dropdown.name = 'programId';
    dropdown.required = true; // Ensure selection is mandatory

    // Add a default "Select Program" option
    const defaultOption = document.createElement('option');
    defaultOption.value = '';
    defaultOption.textContent = 'Select Program';
    dropdown.appendChild(defaultOption);

    // Populate the dropdown with programs
    programs.forEach(program => {
        const option = document.createElement('option');
        option.value = program.id; // Store program ID as the value
        option.textContent = program.name; // Display program name
        if (program.id === selectedProgramId) {
            option.selected = true; // Pre-select the current program
        }
        dropdown.appendChild(option);
    });

    return dropdown.outerHTML; // Return dropdown HTML
}

// Function to save a course
function saveCourse() {
    // Validate inputs
    if (!validateInput('courseId', 'Course ID is required') || 
        !validateInput('courseName', 'Course Name is required') || 
        !validateInput('programId', 'Program selection is required')) { // Ensure program selection is provided
        return; 
    }

    const courseId = document.getElementById('courseId').value; 
    const courseName = document.getElementById('courseName').value; 
    const programId = document.getElementById('programId').value; // Get selected program ID

    const program = programs.find(prog => prog.id === programId); // Find program name
    if (!program) {
        alert('Selected program does not exist.'); // Alert if program does not exist
        return; 
    }
    const programName = program.name; // Get program name based on ID

    // Save the course with programId and programName
    courses.push({ id: courseId, name: courseName, programId, programName }); 
    closeFormModal(); 
    showCourseList(); 
    showSuccessMessage('Course added successfully! '); 
}

// Function to display course list
function showCourseList() {
    const formContainer = document.getElementById('formContainer');
    formContainer.innerHTML = `
        <h3>Courses List</h3>
        <table class="course-table">
            <thead>
                <tr>
                    <th>Course ID</th>
                    <th>Course Name</th>
                    <th>Program Name</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                ${courses.map((course, index) => `
                    <tr>
                        <td id="course-id-${index}" contenteditable="false">${course.id}</td>
                        <td id="course-name-${index}" contenteditable="false">${course.name}</td>
                        <td id="course-program-${index}" contenteditable="false">${course.programName}</td>
                        <td>
                            <button class="edit-btn" id="course-edit-btn-${index}" onclick="toggleCourseEditing(${index})">Edit</button>
                            <button class="remove-btn" onclick="removeCourse(${index})">Remove</button>
                        </td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
}

function toggleCourseEditing(index) {
    const idCell = document.getElementById(`course-id-${index}`);
    const nameCell = document.getElementById(`course-name-${index}`);
    const programCell = document.getElementById(`course-program-${index}`);
    const editButton = document.getElementById(`course-edit-btn-${index}`);

    if (idCell.contentEditable === "false") {
        [idCell, nameCell].forEach(cell => {
            cell.contentEditable = "true";
            cell.style.border = "1px solid #3498db";
            cell.dataset.originalValue = cell.textContent.trim();
        });

        // Replace program name with dropdown
        programCell.innerHTML = populateProgramDropdown(courses[index].programId);

        editButton.textContent = "Save";
    } else {
        const programDropdown = document.getElementById('programId');
        const selectedProgramId = programDropdown.value;
        const program = programs.find(prog => prog.id === selectedProgramId);

        courses[index] = {
            id: idCell.textContent.trim(),
            name: nameCell.textContent.trim(),
            programId: selectedProgramId,
            programName: program ? program.name : ''
        };

        showCourseList();
        showSuccessMessage("Course updated successfully!");
    }
}

function saveCourseOnEnter(event, index, field, cell) {
    if (event.key === "Enter") {
        event.preventDefault();
        const newValue = cell.textContent.trim();

        if (!newValue) {
            alert(`${field.charAt(0).toUpperCase() + field.slice(1)} cannot be empty.`);
            cell.textContent = cell.dataset.originalValue;
        } else {
            courses[index][field] = newValue;
        }

        cell.contentEditable = "false";
        cell.style.border = "none";

        const editButton = document.getElementById(`course-edit-btn-${index}`);
        editButton.textContent = "Edit";

        showSuccessMessage("Course updated successfully!");
    }
}

function saveCourseChanges(index, idCell, nameCell, programCell) {
    const newId = idCell.textContent.trim();
    const newName = nameCell.textContent.trim();
    const newProgramName = programCell.textContent.trim();

    if (!newId) idCell.textContent = idCell.dataset.originalValue;
    if (!newName) nameCell.textContent = nameCell.dataset.originalValue;
    if (!newProgramName) programCell.textContent = programCell.dataset.originalValue;

    courses[index] = {
        id: idCell.textContent.trim(),
        name: nameCell.textContent.trim(),
        programName: programCell.textContent.trim(),
    };

    showSuccessMessage("Course updated successfully!");
}

function removeCourse(index) {
    const courseName = courses[index].name;
    courses.splice(index, 1);
    showCourseList();
    showSuccessMessage(`${courseName} has been removed successfully!`);
}

// Function to save a teacher
function saveTeacher() {
    if (!validateInput('teacherId', 'Teacher ID is required') ||
        !validateInput('teacherName', 'Teacher Name is required') ||
        !validateInput('departmentId', 'Department selection is required')) {
        return;
    }

    const teacherId = document.getElementById('teacherId').value;
    const teacherName = document.getElementById('teacherName').value;
    const departmentId = document.getElementById('departmentId').value;

    const department = departments.find(dept => dept.id === departmentId);
    const departmentName = department ? department.name : '';

    // Save the teacher with department
    teachers.push({ id: teacherId, name: teacherName, departmentId, departmentName });
    closeFormModal();
    showTeacherList();
    showSuccessMessage('Teacher added successfully!');
}

// Function to display teachers list
function showTeacherList() {
    const formContainer = document.getElementById('formContainer');
    formContainer.innerHTML = `
        <h3>Teachers List</h3>
        <table class="teacher-table">
            <thead>
                <tr>
                    <th>Teacher ID</th>
                    <th>Teacher Name</th>
                    <th>Department Name</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                ${teachers.map((teacher, index) => `
                    <tr>
                        <td id="teacher-id-${index}" contenteditable="false">${teacher.id}</td>
                        <td id="teacher-name-${index}" contenteditable="false">${teacher.name}</td>
                        <td id="teacher-department-${index}" contenteditable="false">${teacher.departmentName}</td>
                        <td>
                            <button class="edit-btn" id="teacher-edit-btn-${index}" onclick="toggleTeacherEditing(${index})">Edit</button>
                            <button class="remove-btn" onclick="removeTeacher(${index})">Remove</button>
                        </td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
}

// Function to toggle editing for a teacher
function toggleTeacherEditing(index) {
    const idCell = document.getElementById(`teacher-id-${index}`);
    const nameCell = document.getElementById(`teacher-name-${index}`);
    const departmentCell = document.getElementById(`teacher-department-${index}`);
    const editButton = document.getElementById(`teacher-edit-btn-${index}`);

    if (idCell.contentEditable === "false") {
        // Enable editing for ID and Name
        [idCell, nameCell].forEach(cell => {
            cell.contentEditable = "true";
            cell.style.border = "1px solid #3498db";
            cell.dataset.originalValue = cell.textContent.trim();
        });

        // Replace department name with dropdown for editing
        departmentCell.innerHTML = populateDepartmentDropdown(teachers[index].departmentId);

        editButton.textContent = "Save";
    } else {
        // Retrieve the selected department from the dropdown
        const departmentDropdown = document.getElementById('departmentId');
        const selectedDepartmentId = departmentDropdown.value;
        const department = departments.find(dept => dept.id === selectedDepartmentId);

        // Update the teacher information
        teachers[index] = {
            id: idCell.textContent.trim(),
            name: nameCell.textContent.trim(),
            departmentId: selectedDepartmentId,
            departmentName: department ? department.name : ''
        };

        // Refresh the teacher list to reflect the changes
        showTeacherList();
        showSuccessMessage("Teacher updated successfully!");
    }
}

// Function to remove a teacher
function removeTeacher(index) {
    const teacherName = teachers[index].name;
    teachers.splice(index, 1);
    showTeacherList();
    showSuccessMessage(`${teacherName} has been removed successfully!`);
}

// Function to populate department dropdown
function populateDepartmentDropdown(selectedDepartmentId = '') {
    const dropdown = document.createElement('select');
    dropdown.id = 'departmentId'; // ID for referencing the selected department
    dropdown.name = 'departmentId';
    dropdown.required = true;

    // Add a default "Select Department" option
    const defaultOption = document.createElement('option');
    defaultOption.value = '';
    defaultOption.textContent = 'Select Department';
    dropdown.appendChild(defaultOption);

    // Populate the dropdown with departments
    departments.forEach(department => {
        const option = document.createElement('option');
        option.value = department.id;
        option.textContent = department.name;
        if (department.id === selectedDepartmentId) {
            option.selected = true;
        }
        dropdown.appendChild(option);
    });

    return dropdown.outerHTML; // Return the dropdown as HTML
}


// Function to display room list
function showRoomList() {
    const formContainer = document.getElementById('formContainer');
    formContainer.innerHTML = `
        <h3>Rooms List</h3>
        <table class="room-table">
            <thead>
                <tr>
                    <th>Room No</th>
                    <th>Building</th>
                    <th>Room Type</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                ${rooms.map((room, index) => `
                    <tr>
                        <td id="room-no-${index}" contenteditable="false">${room.roomNo}</td>
                        <td id="room-building-${index}" contenteditable="false">${room.building}</td>
                        <td id="room-type-${index}" contenteditable="false">${room.type}</td>
                        <td>
                            <button class="edit-btn" id="room-edit-btn-${index}" onclick="toggleRoomEditing(${index})">Edit</button>
                            <button class="remove-btn" onclick="removeRoom(${index})">Remove</button>
                        </td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
}

// Function to toggle editing for a room
function toggleRoomEditing(index) {
    const roomNoCell = document.getElementById(`room-no-${index}`);
    const buildingCell = document.getElementById(`room-building-${index}`);
    const typeCell = document.getElementById(`room-type-${index}`);
    const editButton = document.getElementById(`room-edit-btn-${index}`);

    if (roomNoCell.contentEditable === "false") {
        // Enable editing
        [roomNoCell, buildingCell, typeCell].forEach(cell => {
            cell.contentEditable = "true";
            cell.style.border = "1px solid #3498db";
            cell.dataset.originalValue = cell.textContent.trim();
        });

        // Change button text to "Save"
        editButton.textContent = "Save";
    } else {
        // Save changes
        const newRoomNo = roomNoCell.textContent.trim();
        const newBuilding = buildingCell.textContent.trim();
        const newType = typeCell.textContent.trim();

        // Validate inputs
        if (!newRoomNo || !newBuilding || !newType) {
            alert("All fields are required.");
            roomNoCell.textContent = roomNoCell.dataset.originalValue;
            buildingCell.textContent = buildingCell.dataset.originalValue;
            typeCell.textContent = typeCell.dataset.originalValue;
        } else {
            // Update the rooms array
            rooms[index] = { roomNo: newRoomNo, building: newBuilding, type: newType };
        }

        // Disable editing
        [roomNoCell, buildingCell, typeCell].forEach(cell => {
            cell.contentEditable = "false";
            cell.style.border = "none";
        });

        // Change button text back to "Edit"
        editButton.textContent = "Edit";
        showSuccessMessage("Room updated successfully!");
    }
}

// Function to remove a room
function removeRoom(index) {
    if (confirm(`Are you sure you want to remove the room "${rooms[index].roomNo}"?`)) {
        rooms.splice(index, 1); // Remove room from array
        showRoomList(); // Refresh list
        showSuccessMessage("Room removed successfully!");
    }
}

// Function to save a room
function saveRoom() {
    if (!validateInput('roomNo', 'Room No is required') ||
        !validateInput('building', 'Building is required') ||
        !validateInput('roomType', 'Room Type is required')) {
        return;
    }

    const roomNo = document.getElementById('roomNo').value.trim();
    const building = document.getElementById('building').value.trim();
    const roomType = document.getElementById('roomType').value.trim();

    // Save the room without checking for duplicates
    rooms.push({ roomNo, building, type: roomType });

    closeFormModal(); // Close modal after saving
    showRoomList();   // Refresh the list to show the newly added room
    showSuccessMessage('Room added successfully!');
}

// Global array to store timetable entries
let timetableEntries = [];

// Function to navigate to the next step
function nextStep(currentStep) {
    const currentStepElement = document.getElementById(`step${currentStep}`);
    const nextStepElement = document.getElementById(`step${currentStep + 1}`);
    if (nextStepElement) {
        currentStepElement.style.display = 'none';
        nextStepElement.style.display = 'block';

        // Update the timetable title dynamically after completing step 2
        if (currentStep === 2) {
            updateTimetableTitle();
        }
    }
}

// Function to navigate to the previous step
function previousStep(currentStep) {
    const currentStepElement = document.getElementById(`step${currentStep}`);
    const previousStepElement = document.getElementById(`step${currentStep - 1}`);
    if (previousStepElement) {
        currentStepElement.style.display = 'none';
        previousStepElement.style.display = 'block';
    }
}

// Function to close the modal
function closeModal() {
    const modal = document.getElementById('timetableModal');
    modal.style.display = 'none';

    // Reset to the first step
    document.getElementById('step1').style.display = 'block';
    document.getElementById('step2').style.display = 'none';
    document.getElementById('step3').style.display = 'none';
}

function populateTimetableSelectOptions() {
    // Populate Department Dropdown
    const departmentSelect = document.getElementById('department');
    if (departmentSelect) {
        departmentSelect.innerHTML = '<option value="">Select Department</option>';
        departments.forEach(department => {
            const option = document.createElement('option');
            option.value = department.id; // Assuming each department object has an 'id' property
            option.textContent = department.name; // Assuming each department object has a 'name' property
            departmentSelect.appendChild(option);
        });
    }

    // Populate Program Dropdown
    const programSelect = document.getElementById('program');
    if (programSelect) {
        programSelect.innerHTML = '<option value="" disabled selected>Select Program</option>';
        programs.forEach(program => {
            const option = document.createElement('option');
            option.value = program.id; // Assuming each program object has an 'id' property
            option.textContent = program.name; // Assuming each program object has a 'name' property
            programSelect.appendChild(option);
        });
    }

    // Populate Section & Semester Dropdown
    const sectionSemesterSelect = document.getElementById('sectionSemester');
    if (sectionSemesterSelect) {
        sectionSemesterSelect.innerHTML = '<option value="" disabled selected>Select Section & Semester</option>';
        sections.forEach(section => {
            const option = document.createElement('option');
            option.value = section.id; // Assuming each section object has an 'id' property
            option.textContent = `${section.name} (Semester ${section.semester})`; // Combine Section and Semester
            sectionSemesterSelect.appendChild(option);
        });
    }

    // Populate Course Dropdown
    const courseSelect = document.getElementById('course');
    if (courseSelect) {
        courseSelect.innerHTML = '<option value="">Select Course</option>';
        courses.forEach(course => {
            const option = document.createElement('option');
            option.value = course.name; // Assuming each course object has a 'name' property
            option.textContent = course.name;
            courseSelect.appendChild(option);
        });
    }

    // Populate Room Dropdown
    const roomSelect = document.getElementById('roomNo');
    if (roomSelect) {
        roomSelect.innerHTML = '<option value="">Select Room No</option>';
        rooms.forEach(room => {
            const option = document.createElement('option');
            option.value = `${room.type} ${room.building} - ${room.roomNo}`; // Format as "Type Building - RoomNo"
            option.textContent = `${room.type} ${room.building} - ${room.roomNo}`;
            roomSelect.appendChild(option);
        });
    }

    // Populate Teacher Dropdown
    const teacherSelect = document.getElementById('teacher');
    if (teacherSelect) {
        teacherSelect.innerHTML = '<option value="">Select Teacher</option>';
        teachers.forEach(teacher => {
            const option = document.createElement('option');
            option.value = teacher.name; // Assuming each teacher object has a 'name' property
            option.textContent = teacher.name;
            teacherSelect.appendChild(option);
        });
    }
}


// Function to update the timetable title dynamically
function updateTimetableTitle() {
    const programSelect = document.getElementById('program');
    const sectionSemesterSelect = document.getElementById('sectionSemester');

    const programName = programSelect.selectedOptions[0]?.textContent || 'Program';
    const sectionSemester = sectionSemesterSelect.selectedOptions[0]?.textContent || 'Section & Semester';

    const titleElement = document.getElementById('timetableTitle');
    titleElement.textContent = `${programName} - ${sectionSemester}`;
}

function nextStep(currentStep) {
    const currentStepElement = document.getElementById(`step${currentStep}`);
    const nextStepElement = document.getElementById(`step${currentStep + 1}`);
    if (nextStepElement) {
        currentStepElement.style.display = 'none';
        nextStepElement.style.display = 'block';

        // Update the timetable title dynamically after completing step 2
        if (currentStep === 2) {
            updateTimetableTitle();
        }
    }
}


function openAddTimetableModal() {
    const modal = document.getElementById('timetableModal');
    modal.style.display = 'block';
    populateTimetableSelectOptions(); // Populate dropdowns when opening
}



// Close the modal
function closeTimetableModal() {
    const modal = document.getElementById('timetableModal');
    modal.style.display = 'none';
}


function addToGrid() {
    const day = document.getElementById("day").value.trim();
    const timing = document.getElementById("classTiming").value.trim();
    const course = document.getElementById("course").value.trim();
    const teacher = document.getElementById("teacher").value.trim();
    const room = document.getElementById("roomNo").value.trim();
    const slotDuration = parseInt(document.getElementById("slotDuration").value, 10); // 1 Hour or 3 Hours

    // Validate inputs
    if (!day || !timing || !course || !teacher || !room) {
        alert("All fields are required. Please fill them out.");
        return;
    }

    const timeSlots = [
        "8:30-9:30",
        "9:30-10:30",
        "10:30-11:30",
        "11:30-12:30",
        "12:30-1:30",
        "1:30-2:30",
        "2:30-3:30",
        "3:30-4:30",
    ];

    const startTime = timing.split("-")[0];
    const startIndex = timeSlots.findIndex(slot => slot.startsWith(startTime));

    if (startIndex === -1 || startIndex + slotDuration > timeSlots.length) {
        alert("Invalid or overlapping time slots selected.");
        return;
    }

    // Locate the row for the selected day
    const row = document.querySelector(`tr[data-day="${day}"]`);

    if (!row) {
        alert(`Could not find a row for Day: ${day}`);
        return;
    }

    const cells = Array.from(row.querySelectorAll(".timetable-cell"));

    // Fill the first cell with content and span horizontally
    const firstCell = cells[startIndex];
    if (firstCell) {
        firstCell.innerHTML = `
            <strong>${room}</strong><br>
            <strong>${course}</strong><br>
            <small>${teacher}</small>
        `;
        firstCell.setAttribute("colspan", slotDuration); // Span horizontally
        firstCell.style.backgroundColor = "#d1e7dd"; // Optional: Highlight the first cell

        // Hide the following cells that are part of the same span
        for (let i = 1; i < slotDuration; i++) {
            const nextCell = cells[startIndex + i];
            if (nextCell) {
                nextCell.style.display = "none"; // Hide subsequent cells
            }
        }
    }
}


function updateGrid(day, startTime, room, course, teacher, slotDuration) {
    const timeSlots = [
        "8:30-9:30",
        "9:30-10:30",
        "10:30-11:30",
        "11:30-12:30",
        "12:30-1:30",
        "1:30-2:30",
        "2:30-3:30",
        "3:30-4:30",
    ];

    const startIndex = timeSlots.findIndex(slot => slot.startsWith(startTime));

    if (startIndex === -1 || startIndex + slotDuration > timeSlots.length) {
        alert("Invalid or overlapping time slots selected.");
        return;
    }

    for (let i = 0; i < slotDuration; i++) {
        const currentSlot = timeSlots[startIndex + i];
        const cell = document.querySelector(
            `tr[data-day="${day}"] .timetable-cell[data-time="${currentSlot}"]`
        );

        if (cell) {
            if (i === 0) {
                // Fill the first cell with full content
                cell.innerHTML = `
                    <strong>${room}</strong><br>
                    <strong>${course}</strong><br>
                    <small>${teacher}</small>
                `;
                cell.style.backgroundColor = "#d1e7dd"; // Highlight the first cell
                cell.setAttribute("rowspan", slotDuration); // Mark as part of a span
            } else {
                // Mark the other cells as part of the span but visually empty
                cell.innerHTML = ""; // Leave empty
                cell.style.display = "none"; // Hide subsequent cells
            }
        }
    }
}

function generateTimetableRows() {
    const days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"];
    const timeSlots = [
        "8:30-9:30",
        "9:30-10:30",
        "10:30-11:30",
        "11:30-12:30",
        "12:30-1:30",
        "1:30-2:30",
        "2:30-3:30",
        "3:30-4:30",
    ];

    // Generate timetable header with time slots only
    let tableHTML = `
        <thead>
            <tr>
                <th>Day/Time</th>
                ${timeSlots.map(time => `<th>${time}</th>`).join("")}
            </tr>
        </thead>
        <tbody>
            ${days
                .map(
                    day => `
                    <tr data-day="${day}">
                        <td>${day}</td>
                        ${timeSlots
                            .map(
                                (time, index) => `
                                <td class="timetable-cell" 
                                    data-time="${time}" 
                                    data-time-index="${index}" 
                                    data-day="${day}">
                                </td>
                            `
                            )
                            .join("")}
                    </tr>
                `
                )
                .join("")}
        </tbody>
    `;
    return tableHTML;
}


function showTimetable() {
    const formContainer = document.getElementById("formContainer");

    // Retrieve dynamically selected program, section, and semester
    const programSelect = document.getElementById("program");
    const sectionSemesterSelect = document.getElementById("sectionSemester");

    const programName = programSelect?.selectedOptions[0]?.textContent || "Select Program";
    const sectionSemester = sectionSemesterSelect?.selectedOptions[0]?.textContent || "Select Section & Semester";

    // Extract section and numeric part of semester
    const section = sectionSemester.match(/[A-Za-z]+/)?.[0] || "";
    const semesterNumber = sectionSemester.match(/\d+/)?.[0] || "";

    // Ensure valid selections
    if (!programSelect.value || !sectionSemesterSelect.value) {
        alert("Please select both Program and Section & Semester before viewing the timetable.");
        return;
    }

    // Dynamically update timetable title
    const timetableTitle = `${programName} - ${section}(${semesterNumber})`;

    // Generate timetable HTML
    const timetableHTML = `
        <h2 id="timetableHeader" class="timetable-title">${timetableTitle}</h2>
        <table class="timetable-table">
            ${generateTimetableRows()}
        </table>
    `;

    // Insert the timetable HTML into the container
    formContainer.innerHTML = timetableHTML;

    // Attach cell event listeners for editing and multi-slot handling
    attachCellEventListeners();
}


function attachCellEventListeners() {
    const timetableCells = document.querySelectorAll(".timetable-cell");
    timetableCells.forEach(cell => {
        cell.addEventListener("click", () => {
            const time = cell.dataset.time;
            const day = cell.closest("tr").dataset.day;

            openEditModal(cell, day, time);
        });
    });
}

function openEditModal(cell, day, time) {
    // Remove existing modal if any
    const existingModal = document.getElementById("editModal");
    if (existingModal) existingModal.remove();

    // Extract current slot details
    const currentRoom = cell.querySelector("strong")?.innerText || "";
    const currentCourse = cell.querySelectorAll("strong")[1]?.innerText || "";
    const currentTeacher = cell.querySelector("small")?.innerText || "";

    // Create modal HTML dynamically with full room information
    const modalHTML = `
        <div id="editModal" class="modal">
            <div class="modal-content">
                <h3>Edit Timetable Slot</h3>
                <label for="editRoom">Room:</label>
                <select id="editRoom">
                    ${rooms.map(room => 
                        `<option value="${room.roomNo}" ${room.roomNo === currentRoom ? "selected" : ""}>
                            ${room.type} - ${room.building} (Room ${room.roomNo})
                        </option>`
                    ).join("")}
                </select>
                <label for="editCourse">Course:</label>
                <select id="editCourse">
                    ${courses.map(course => 
                        `<option value="${course.name}" ${course.name === currentCourse ? "selected" : ""}>
                            ${course.name}
                        </option>`
                    ).join("")}
                </select>
                <label for="editTeacher">Teacher:</label>
                <select id="editTeacher">
                    ${teachers.map(teacher => 
                        `<option value="${teacher.name}" ${teacher.name === currentTeacher ? "selected" : ""}>
                            ${teacher.name}
                        </option>`
                    ).join("")}
                </select>
                <button id="saveEdit" style="background-color: green; color: white;">Save</button>
                <button id="deleteSlot" style="background-color: red; color: white;">Delete</button>
                <button id="closeModal">Close</button>
            </div>
        </div>
    `;
    document.body.insertAdjacentHTML("beforeend", modalHTML);

    // Event listeners for modal actions
    document.getElementById("saveEdit").addEventListener("click", () => saveSlot(day, time, cell));
    document.getElementById("deleteSlot").addEventListener("click", () => clearSlot(day, time, cell));
    document.getElementById("closeModal").addEventListener("click", closeEditModal);
}

function saveSlot(day, time, cell) {
    const room = document.getElementById("editRoom").value;
    const course = document.getElementById("editCourse").value;
    const teacher = document.getElementById("editTeacher").value;

    if (!room || !course || !teacher) {
        alert("All fields are required.");
        return;
    }

    // Update cell content
    const selectedRoom = rooms.find(r => r.roomNo === room);
    const fullRoomInfo = selectedRoom ? `${selectedRoom.type} - ${selectedRoom.building} ${selectedRoom.roomNo}` : room;

    cell.innerHTML = `
        <strong>${fullRoomInfo}</strong><br>
        <strong>${course}</strong><br>
        <small>${teacher}</small>
    `;
    cell.style.backgroundColor = "#d1e7dd"; // Optional: Highlight the updated cell

    closeEditModal();
}

function clearSlot(day, time, cell) {
    // Clear cell content and reset its style
    cell.innerHTML = "";
    cell.style.backgroundColor = ""; // Remove background highlight
    closeEditModal();
}

function closeEditModal() {
    const modal = document.getElementById("editModal");
    if (modal) modal.remove();
}


function updateGrid(day, startTime, room, course, teacher, slotDuration) {
    const timeSlots = [
        "8:30-9:30",
        "9:30-10:30",
        "10:30-11:30",
        "11:30-12:30",
        "12:30-1:30",
        "1:30-2:30",
        "2:30-3:30",
        "3:30-4:30",
    ];

    const startIndex = timeSlots.findIndex(slot => slot.startsWith(startTime));

    if (startIndex === -1 || startIndex + slotDuration > timeSlots.length) {
        alert("Invalid or overlapping time slots selected.");
        return;
    }

    // Clear any existing slots for the duration
    clearGridSlots(day, startTime);

    for (let i = 0; i < slotDuration; i++) {
        const currentSlot = timeSlots[startIndex + i];
        const cell = document.querySelector(
            `tr[data-day="${day}"] .timetable-cell[data-time="${currentSlot}"]`
        );

        if (cell) {
            if (i === 0) {
                // Fill the first cell with full content
                cell.innerHTML = `
                    <strong>${room}</strong><br>
                    <strong>${course}</strong><br>
                    <small>${teacher}</small>
                `;
                cell.style.backgroundColor = "#d1e7dd"; // Highlight the first cell
                cell.setAttribute("data-span", slotDuration); // Mark as spanned
            } else {
                // Mark other cells as part of the span but visually empty
                cell.innerHTML = "";
                cell.style.backgroundColor = "#f8f9fa"; // Continuity color
                cell.setAttribute("data-part-of-span", "true"); // Custom attribute
            }
        }
    }
}


function clearGridSlots(day, startTime) {
    const timeSlots = [
        "8:30-9:30",
        "9:30-10:30",
        "10:30-11:30",
        "11:30-12:30",
        "12:30-1:30",
        "1:30-2:30",
        "2:30-3:30",
        "3:30-4:30",
    ];

    const startIndex = timeSlots.findIndex(slot => slot.startsWith(startTime));
    const firstCell = document.querySelector(
        `tr[data-day="${day}"] .timetable-cell[data-time="${timeSlots[startIndex]}"]`
    );

    const slotDuration = firstCell ? parseInt(firstCell.getAttribute("data-span"), 10) : 1;

    for (let i = 0; i < slotDuration; i++) {
        const currentSlot = timeSlots[startIndex + i];
        const cell = document.querySelector(
            `tr[data-day="${day}"] .timetable-cell[data-time="${currentSlot}"]`
        );

        if (cell) {
            cell.innerHTML = ""; // Clear content
            cell.style.backgroundColor = ""; // Reset background
            cell.removeAttribute("data-span");
            cell.removeAttribute("data-part-of-span");
        }
    }
}

function deleteItem(type, index) {
    if (confirm(`Are you sure you want to delete this ${type}?`)) {
        window[type + 's'].splice(index, 1);
        showList(type, window[type + 's']);
    }
}

function searchItems(type) {
    const searchTerm = document.getElementById(`${type}Search`).value.toLowerCase();
    const filteredItems = window[type + 's'].filter(item => 
        Object.values(item).some(value => 
            value.toString().toLowerCase().includes(searchTerm)
        )
    );
    showList(type, filteredItems);
}

function toggleDropdown(dropdownId) {
    const dropdown = document.getElementById(dropdownId);
    document.querySelectorAll('.dropdown-content').forEach(content => {
        if (content !== dropdown) {
            content.style.display = 'none';
        }
    });
    dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
}

function validateRelatedEntity(entityType, entityId) {
    const entity = window[entityType + 's'].find(item => item.id === entityId);
    if (!entity) {
        alert(`${entityType.charAt(0).toUpperCase() + entityType.slice(1)} with ID ${entityId} does not exist.`);
        return false;
    }
    return true;
}

function showSuccessMessage(message) {
    const formContainer = document.getElementById('formContainer');
    const successDiv = document.createElement('div');
    successDiv.className = 'success-message';
    successDiv.textContent = message;
    formContainer.appendChild(successDiv);
    setTimeout(() => {
        successDiv.remove();
    }, 3000);
}

function showList(type, items) {
    const formContainer = document.getElementById('formContainer');
    let tableHTML = '';

    switch (type) {
        case 'department':
            tableHTML = `
                <h3>Departments List</h3>
                <table class="department-table">
                    <thead>
                        <tr>
                            <th>Department ID</th>
                            <th>Department Name</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${departments.map((dept, index) => `
                            <tr>
                                <td id="department-id-${index}" contenteditable="false">${dept.id}</td>
                                <td id="department-name-${index}" contenteditable="false">${dept.name}</td>
                                <td>
                                    <button class="edit-btn" id="department-edit-btn-${index}" onclick="toggleDepartmentEditing(${index})">Edit</button>
                                    <button class="remove-btn" onclick="removeDepartment(${index})">Remove</button>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>`;
            break;
        
        

        case 'program':
            tableHTML = `
                <h3>Programs List</h3>
                <table class="program-table">
                    <thead>
                        <tr>
                            <th>Program ID</th>
                            <th>Program Name</th>
                            <th>Department Name</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${items.map((prog, index) => `
                            <tr>
                                <td id="program-id-${index}" contenteditable="false">${prog.id}</td>
                                <td id="program-name-${index}" contenteditable="false">${prog.name}</td>
                                <td id="program-department-${index}" contenteditable="false">${prog.departmentName}</td>
                                <td>
                                    <button class="edit-btn" id="program-edit-btn-${index}" onclick="toggleProgramEditing(${index})">Edit</button>
                                    <button class="remove-btn" onclick="removeItem('program', ${index})">Remove</button>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>`;
            break;

        case 'course':
            tableHTML = `
                <h3>Courses List</h3>
                <table class="course-table">
                    <thead>
                        <tr>
                            <th>Course ID</th>
                            <th>Course Name</th>
                            <th>Program Name</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${items.map((course, index) => `
                            <tr>
                                <td id="course-id-${index}" contenteditable="false">${course.id}</td>
                                <td id="course-name-${index}" contenteditable="false">${course.name}</td>
                                <td id="course-program-${index}" contenteditable="false">${course.programName}</td>
                                <td>
                                    <button class="edit-btn" id="course-edit-btn-${index}" onclick="toggleCourseEditing(${index})">Edit</button>
                                    <button class="remove-btn" onclick="removeItem('course', ${index})">Remove</button>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>`;
            break;

        case 'teacher':
            tableHTML = `
                <h3>Teachers List</h3>
                <table class="teacher-table">
                    <thead>
                        <tr>
                            <th>Teacher ID</th>
                            <th>Teacher Name</th>
                            <th>Department Name</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${items.map((teacher, index) => `
                            <tr>
                                <td id="teacher-id-${index}" contenteditable="false">${teacher.id}</td>
                                <td id="teacher-name-${index}" contenteditable="false">${teacher.name}</td>
                                <td id="teacher-department-${index}" contenteditable="false">${teacher.departmentName}</td>
                                <td>
                                    <button class="edit-btn" id="teacher-edit-btn-${index}" onclick="toggleTeacherEditing(${index})">Edit</button>
                                    <button class="remove-btn" onclick="removeItem('teacher', ${index})">Remove</button>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>`;
            break;

        case 'room':
            tableHTML = `
                <h3>Rooms List</h3>
                <table class="room-table">
                    <thead>
                        <tr>
                            <th>Room No</th>
                            <th>Building</th>
                            <th>Room Type</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${items.map((room, index) => `
                            <tr>
                                <td id="room-no-${index}" contenteditable="false">${room.roomNo}</td>
                                <td id="room-building-${index}" contenteditable="false">${room.building}</td>
                                <td id="room-type-${index}" contenteditable="false">${room.type}</td>
                                <td>
                                    <button class="edit-btn" id="room-edit-btn-${index}" onclick="toggleRoomEditing(${index})">Edit</button>
                                    <button class="remove-btn" onclick="removeItem('room', ${index})">Remove</button>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>`;
            break;

        case 'session':
            tableHTML = `
                <h3>Sessions List</h3>
                <table class="session-table">
                    <thead>
                        <tr>
                            <th>Session ID</th>
                            <th>Session Name</th>
                            <th>Year</th>
                            <th>Type</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${items.map((session, index) => `
                            <tr>
                                <td id="session-id-${index}" contenteditable="false">${session.id}</td>
                                <td id="session-name-${index}" contenteditable="false">${session.name}</td>
                                <td id="session-year-${index}" contenteditable="false">${session.year}</td>
                                <td id="session-type-${index}" contenteditable="false">${session.type}</td>
                                <td>
                                    <button class="edit-btn" id="session-edit-btn-${index}" onclick="toggleSessionEditing(${index})">Edit</button>
                                    <button class="remove-btn" onclick="removeItem('session', ${index})">Remove</button>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>`;
            break;

        case 'section':
            tableHTML = `
                <h3>Sections List</h3>
                <table class="section-table">
                    <thead>
                        <tr>
                            <th>Section ID</th>
                            <th>Section Name</th>
                            <th>Semester</th>
                            <th>Program Name</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${items.map((section, index) => `
                            <tr>
                                <td id="section-id-${index}" contenteditable="false">${section.id}</td>
                                <td id="section-name-${index}" contenteditable="false">${section.name}</td>
                                <td id="section-semester-${index}" contenteditable="false">${section.semester}</td>
                                <td id="section-program-${index}" contenteditable="false">${section.programName}</td>
                                <td>
                                    <button class="edit-btn" id="section-edit-btn-${index}" onclick="toggleSectionEditing(${index})">Edit</button>
                                    <button class="remove-btn" onclick="removeItem('section', ${index})">Remove</button>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>`;
            break;
    }

    formContainer.innerHTML = tableHTML;
}




function deleteItem(type, index) {
    const entityName = type.charAt(0).toUpperCase() + type.slice(1);
    
    switch(type) {
        case 'department':
            departments.splice(index, 1);
            break;
        case 'program':
            programs.splice(index, 1);
            break;
        case 'course':
            courses.splice(index, 1);
            break;
        case 'teacher':
            teachers.splice(index, 1);
            break;
        case 'room':
            rooms.splice(index, 1);
            break;
        case 'session':
            sessions.splice(index, 1);
            break;
        case 'section':
            sections.splice(index, 1);
            break;
    }
    showList(type, window[type + 's']);
    showSuccessMessage(`${entityName} deleted successfully!`);
}

function showSuccessMessage(message) {
    const messageDiv = document.createElement('div');
    messageDiv.className = 'success-message';
    messageDiv.textContent = message;
    document.getElementById('formContainer').insertBefore(messageDiv, document.getElementById('formContainer').firstChild);
    
    setTimeout(() => {
        messageDiv.remove();
    }, 3000);
}

function validateInput(id, errorMessage) {
    const input = document.getElementById(id);
    if (!input.value.trim()) {
        alert(errorMessage); // or use a better UI method to show errors
        return false;
    }
    return true;
}

function validateRelatedEntity(type, id) {
    let exists = false;
    switch(type) {
        case 'department':
            exists = departments.some(dept => dept.id === id);
            break;
        case 'program':
            exists = programs.some(prog => prog.id === id);
            break;
    }
    if (!exists) {
        alert(`${type.charAt(0).toUpperCase() + type.slice(1)} with ID ${id} does not exist!`);
        return false;
    }
    return true;
}

// Add event listener when document loads
document.addEventListener('DOMContentLoaded', function() {
    const sidebarButtons = document.querySelectorAll('.sidebar-button');
    sidebarButtons.forEach(button => {
        button.addEventListener('click', function() {
            const type = this.getAttribute('data-type');
            if (type) {
                showList(type, window[type + 's']);
            }
        });
    });
});

async function submitTimetable(data) {
    try {
        const response = await fetch('http://localhost:5000/api/timetable', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });

        if (!response.ok) {
            const errorData = await response.json();
            alert(errorData.error); // Show error message
        } else {
            alert('Timetable entry created successfully!');
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Something went wrong!');
    }
}


document.getElementById('submit-button').addEventListener('click', () => {
    const data = {
        course_id: document.getElementById('course').value,
        teacher_id: document.getElementById('teacher').value,
        room_id: document.getElementById('room').value,
        time_slot_id: document.getElementById('time_slot').value,
        day: document.getElementById('day').value
    };
    submitTimetable(data); // Send data to backend
});

document.addEventListener('DOMContentLoaded', () => {
    // Call functions to populate dropdowns on page load
    populateTimetableSelectOptions(); // Ensures all dropdowns are pre-populated
});
