-- Create the database
CREATE DATABASE  Timetable_Management;
USE Timetable_Management;

-- Users Table
CREATE TABLE Users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('admin', 'instructor') NOT NULL,
    department_id INT,
    FOREIGN KEY (department_id) REFERENCES Departments(department_id) ON DELETE SET NULL
);

-- Departments Table
CREATE TABLE Departments (
    department_id INT AUTO_INCREMENT PRIMARY KEY,
    department_name VARCHAR(100) NOT NULL UNIQUE
);

-- Programs Table
CREATE TABLE Programs (
    program_id INT AUTO_INCREMENT PRIMARY KEY,
    program_name VARCHAR(100) NOT NULL UNIQUE,
    department_id INT NOT NULL,
    FOREIGN KEY (department_id) REFERENCES Departments(department_id) ON DELETE CASCADE
);

-- Courses Table
CREATE TABLE Courses (
    course_id INT AUTO_INCREMENT PRIMARY KEY,
    course_name VARCHAR(100) NOT NULL,
    program_id INT NOT NULL,
    FOREIGN KEY (program_id) REFERENCES Programs(program_id) ON DELETE CASCADE
);

-- Teachers Table
CREATE TABLE Teachers (
    teacher_id INT AUTO_INCREMENT PRIMARY KEY,
    teacher_name VARCHAR(100) NOT NULL,
    department_id INT NOT NULL,
    FOREIGN KEY (department_id) REFERENCES Departments(department_id) ON DELETE CASCADE
);

-- Rooms Table
CREATE TABLE Rooms (
    room_id INT AUTO_INCREMENT PRIMARY KEY,
    room_no VARCHAR(20) NOT NULL UNIQUE,
    building VARCHAR(100) NOT NULL,
    room_type ENUM('lecture', 'lab', 'seminar') NOT NULL
);

-- Sessions Table
CREATE TABLE Sessions (
    session_id INT AUTO_INCREMENT PRIMARY KEY,
    session_name VARCHAR(100) NOT NULL,
    session_year YEAR NOT NULL,
    session_type ENUM('Spring', 'Fall') NOT NULL
);

-- Sections Table
CREATE TABLE Sections (
    section_id INT AUTO_INCREMENT PRIMARY KEY,
    section_name VARCHAR(100) NOT NULL,
    semester INT NOT NULL,
    program_id INT NOT NULL,
    FOREIGN KEY (program_id) REFERENCES Programs(program_id) ON DELETE CASCADE
);

-- Timetable Table
CREATE TABLE Timetable (
    timetable_id INT AUTO_INCREMENT PRIMARY KEY,
    day ENUM('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday') NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    course_id INT NOT NULL,
    teacher_id INT NOT NULL,
    room_id INT NOT NULL,
    section_id INT NOT NULL,
    FOREIGN KEY (course_id) REFERENCES Courses(course_id) ON DELETE CASCADE,
    FOREIGN KEY (teacher_id) REFERENCES Teachers(teacher_id) ON DELETE CASCADE,
    FOREIGN KEY (room_id) REFERENCES Rooms(room_id) ON DELETE CASCADE,
    FOREIGN KEY (section_id) REFERENCES Sections(section_id) ON DELETE CASCADE,
    CONSTRAINT UC_Timetable UNIQUE (day, start_time, end_time, teacher_id),
    CONSTRAINT UC_Timetable_Room UNIQUE (day, start_time, end_time, room_id)
);

 show tables;
 SELECT * FROM Users WHERE username = 'admin';
 SELECT DATABASE();
 -- Insert data into Departments
INSERT INTO Departments (department_id, department_name) VALUES 
(1, 'Computer Science'),
(2, 'Mathematics');
UPDATE Departments
SET department_name = 'IT'
WHERE department_id = 1;

UPDATE Departments
SET department_name = 'Numerical Sciences'
WHERE department_id = 2;


-- Insert data into Programs
INSERT INTO Programs (program_id, program_name, department_id) VALUES 
(1, 'BSc Computer Science', 1),
(2, 'BSc Mathematics', 2);

-- Insert data into Courses
INSERT INTO Courses (course_id, course_name, program_id) VALUES 
(1, 'Introduction to Programming', 1),
(2, 'Calculus I', 2);

-- Insert data into Teachers
INSERT INTO Teachers (teacher_id, teacher_name, department_id) VALUES 
(1, 'John Doe', 1),
(2, 'Jane Smith', 2);

-- Insert data into Rooms
INSERT INTO Rooms (room_id, room_no, building, room_type) VALUES 
(1, '101', 'Main Building', 'lecture'),
(2, '202', 'Science Block', 'lab');

-- Insert data into Sessions
INSERT INTO Sessions (session_id, session_name, session_year, session_type) VALUES 
(1, 'Session 2024', 2024, 'Spring'),
(2, 'Session 2024', 2024, 'Fall');

-- Insert data into Sections
INSERT INTO Sections (section_id, section_name, semester, program_id) VALUES 
(1, 'CS-1', 1, 1),
(2, 'Math-1', 1, 2);

-- Insert data into Users
INSERT INTO Users (user_id, username, password_hash, role, department_id) VALUES 
(1, 'admin', '$2b$10$XQy6m6VfQELCjFZcFZyxmO9Y19/VPLXzXt54IciqTFo.YyD54QyoO', 'admin', 1),
(2, 'instructor1', '$2b$10$hhYdTcHoO.FZkN9/sNpC8uWhW7qMI6djoC6LSiKwxnFMaTqHbF9Ni', 'instructor', 2);
UPDATE Users
SET password_hash = '$2b$10$XQy6m6VfQELCjFZcFZyxmO9Y19/VPLXzXt54IciqTFo.YyD54QyoO'
WHERE username = 'admin';

-- Insert data into Timetable
INSERT INTO Timetable (timetable_id, day, start_time, end_time, course_id, teacher_id, room_id, section_id) VALUES 
(1, 'Monday', '08:30:00', '09:30:00', 1, 1, 1, 1),
(2, 'Monday', '09:30:00', '10:30:00', 2, 2, 2, 2);

-- Show tables and verify data
SHOW TABLES;
SHOW DATABASES;
DESCRIBE Users;
SELECT * FROM Users;
SELECT * FROM Departments;
SELECT * FROM Teachers;
SELECT * FROM Timetable






